# Step #1 Load the Data


```python
import math 
import numpy as np 
import pandas as pd 
from datetime import date, timedelta, datetime 
from pandas.plotting import register_matplotlib_converters 
import matplotlib.pyplot as plt 
import matplotlib.dates as mdates  
from sklearn.metrics import mean_absolute_error, mean_squared_error # Packages for measuring model performance / errors
from keras.models import Sequential # Deep learning library, used for neural networks
from keras.layers import LSTM, Dense, Dropout # Deep learning classes for recurrent and regular densely-connected layers
from keras.callbacks import EarlyStopping # EarlyStopping during model training
from sklearn.preprocessing import RobustScaler, MinMaxScaler # This Scaler removes the median and scales the data according to the quantile range to normalize the price data 
import seaborn as sns
today = date.today()
date_today = today.strftime("%Y-%m-%d")
stockname = 'NASDAQ'
date_start = '2016-01-04'

df=pd.read_csv(r'https://raw.githubusercontent.com/Fluid-AI/marketprophecy/main/NASDAQ%20Data/NASDAQ%20Training%20Data%20-%201st%20Jan%202016%20to%201st%20Jan%202022.csv',index_col=['Date'])
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Adj Close</th>
      <th>Volume</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2016-01-04</th>
      <td>4897.649902</td>
      <td>4903.089844</td>
      <td>4846.979980</td>
      <td>4903.089844</td>
      <td>4903.089844</td>
      <td>2218420000</td>
    </tr>
    <tr>
      <th>2016-01-05</th>
      <td>4917.839844</td>
      <td>4926.729980</td>
      <td>4872.740234</td>
      <td>4891.430176</td>
      <td>4891.430176</td>
      <td>1927380000</td>
    </tr>
    <tr>
      <th>2016-01-06</th>
      <td>4813.759766</td>
      <td>4866.040039</td>
      <td>4804.689941</td>
      <td>4835.759766</td>
      <td>4835.759766</td>
      <td>2168620000</td>
    </tr>
    <tr>
      <th>2016-01-07</th>
      <td>4736.399902</td>
      <td>4788.020020</td>
      <td>4688.169922</td>
      <td>4689.430176</td>
      <td>4689.430176</td>
      <td>2552590000</td>
    </tr>
    <tr>
      <th>2016-01-08</th>
      <td>4722.020020</td>
      <td>4742.569824</td>
      <td>4637.850098</td>
      <td>4643.629883</td>
      <td>4643.629883</td>
      <td>2288750000</td>
    </tr>
  </tbody>
</table>
</div>



# Step #2 Exploring the Data


```python
# Plot line charts
df_plot = df.copy()

list_length = df_plot.shape[1]
ncols = 2
nrows = int(round(list_length / ncols, 0))

fig, ax = plt.subplots(nrows=nrows, ncols=ncols, sharex=True, figsize=(14, 7))
fig.subplots_adjust(hspace=0.5, wspace=0.5)
for i in range(0, list_length):
        ax = plt.subplot(nrows,ncols,i+1)
        sns.lineplot(data = df_plot.iloc[:, i], ax=ax)
        ax.set_title(df_plot.columns[i])
        ax.tick_params(axis="x", rotation=30, labelsize=10, length=0)
        ax.xaxis.set_major_locator(mdates.AutoDateLocator())
fig.tight_layout()
plt.show()
```


    
![png](output_3_0.png)
    


# Step #3 Preprocessing and Feature Selection


```python
# Indexing Batches
train_df = df.sort_values(by=['Date']).copy()
train_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Adj Close</th>
      <th>Volume</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2016-01-04</th>
      <td>4897.649902</td>
      <td>4903.089844</td>
      <td>4846.979980</td>
      <td>4903.089844</td>
      <td>4903.089844</td>
      <td>2218420000</td>
    </tr>
    <tr>
      <th>2016-01-05</th>
      <td>4917.839844</td>
      <td>4926.729980</td>
      <td>4872.740234</td>
      <td>4891.430176</td>
      <td>4891.430176</td>
      <td>1927380000</td>
    </tr>
    <tr>
      <th>2016-01-06</th>
      <td>4813.759766</td>
      <td>4866.040039</td>
      <td>4804.689941</td>
      <td>4835.759766</td>
      <td>4835.759766</td>
      <td>2168620000</td>
    </tr>
    <tr>
      <th>2016-01-07</th>
      <td>4736.399902</td>
      <td>4788.020020</td>
      <td>4688.169922</td>
      <td>4689.430176</td>
      <td>4689.430176</td>
      <td>2552590000</td>
    </tr>
    <tr>
      <th>2016-01-08</th>
      <td>4722.020020</td>
      <td>4742.569824</td>
      <td>4637.850098</td>
      <td>4643.629883</td>
      <td>4643.629883</td>
      <td>2288750000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2020-12-24</th>
      <td>12791.540039</td>
      <td>12833.549805</td>
      <td>12767.639648</td>
      <td>12804.730469</td>
      <td>12804.730469</td>
      <td>3305950000</td>
    </tr>
    <tr>
      <th>2020-12-28</th>
      <td>12914.639648</td>
      <td>12930.889648</td>
      <td>12827.450195</td>
      <td>12899.419922</td>
      <td>12899.419922</td>
      <td>5076340000</td>
    </tr>
    <tr>
      <th>2020-12-29</th>
      <td>12965.389648</td>
      <td>12973.330078</td>
      <td>12821.959961</td>
      <td>12850.219727</td>
      <td>12850.219727</td>
      <td>4680780000</td>
    </tr>
    <tr>
      <th>2020-12-30</th>
      <td>12906.509766</td>
      <td>12924.929688</td>
      <td>12857.759766</td>
      <td>12870.000000</td>
      <td>12870.000000</td>
      <td>5292210000</td>
    </tr>
    <tr>
      <th>2020-12-31</th>
      <td>12877.089844</td>
      <td>12902.070313</td>
      <td>12821.230469</td>
      <td>12888.280273</td>
      <td>12888.280273</td>
      <td>4771390000</td>
    </tr>
  </tbody>
</table>
<p>1259 rows × 6 columns</p>
</div>




```python
date_index = train_df.index
date_index
```




    Index(['2016-01-04', '2016-01-05', '2016-01-06', '2016-01-07', '2016-01-08',
           '2016-01-11', '2016-01-12', '2016-01-13', '2016-01-14', '2016-01-15',
           ...
           '2020-12-17', '2020-12-18', '2020-12-21', '2020-12-22', '2020-12-23',
           '2020-12-24', '2020-12-28', '2020-12-29', '2020-12-30', '2020-12-31'],
          dtype='object', name='Date', length=1259)




```python
# Adding Month and Year in separate columns
d = pd.to_datetime(train_df.index)
d
```




    DatetimeIndex(['2016-01-04', '2016-01-05', '2016-01-06', '2016-01-07',
                   '2016-01-08', '2016-01-11', '2016-01-12', '2016-01-13',
                   '2016-01-14', '2016-01-15',
                   ...
                   '2020-12-17', '2020-12-18', '2020-12-21', '2020-12-22',
                   '2020-12-23', '2020-12-24', '2020-12-28', '2020-12-29',
                   '2020-12-30', '2020-12-31'],
                  dtype='datetime64[ns]', name='Date', length=1259, freq=None)




```python
train_df['Month'] = d.strftime("%m")
train_df['Year'] = d.strftime("%Y") 

```


```python
train_df = train_df.reset_index(drop=True).copy()
train_df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Adj Close</th>
      <th>Volume</th>
      <th>Month</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4897.649902</td>
      <td>4903.089844</td>
      <td>4846.979980</td>
      <td>4903.089844</td>
      <td>4903.089844</td>
      <td>2218420000</td>
      <td>01</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4917.839844</td>
      <td>4926.729980</td>
      <td>4872.740234</td>
      <td>4891.430176</td>
      <td>4891.430176</td>
      <td>1927380000</td>
      <td>01</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4813.759766</td>
      <td>4866.040039</td>
      <td>4804.689941</td>
      <td>4835.759766</td>
      <td>4835.759766</td>
      <td>2168620000</td>
      <td>01</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4736.399902</td>
      <td>4788.020020</td>
      <td>4688.169922</td>
      <td>4689.430176</td>
      <td>4689.430176</td>
      <td>2552590000</td>
      <td>01</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4722.020020</td>
      <td>4742.569824</td>
      <td>4637.850098</td>
      <td>4643.629883</td>
      <td>4643.629883</td>
      <td>2288750000</td>
      <td>01</td>
      <td>2016</td>
    </tr>
  </tbody>
</table>
</div>




```python
# List of considered Features
FEATURES = ['High', 'Low', 'Open', 'Close',
            'Volume','Month']
```


```python
print([f for f in FEATURES])
```

    ['High', 'Low', 'Open', 'Close', 'Volume', 'Month']
    


```python
# Create the dataset with features and filter the data to the list of FEATURES
data = pd.DataFrame(train_df)
data_filtered = data[FEATURES]
data_filtered
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>High</th>
      <th>Low</th>
      <th>Open</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4903.089844</td>
      <td>4846.979980</td>
      <td>4897.649902</td>
      <td>4903.089844</td>
      <td>2218420000</td>
      <td>01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4926.729980</td>
      <td>4872.740234</td>
      <td>4917.839844</td>
      <td>4891.430176</td>
      <td>1927380000</td>
      <td>01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4866.040039</td>
      <td>4804.689941</td>
      <td>4813.759766</td>
      <td>4835.759766</td>
      <td>2168620000</td>
      <td>01</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4788.020020</td>
      <td>4688.169922</td>
      <td>4736.399902</td>
      <td>4689.430176</td>
      <td>2552590000</td>
      <td>01</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4742.569824</td>
      <td>4637.850098</td>
      <td>4722.020020</td>
      <td>4643.629883</td>
      <td>2288750000</td>
      <td>01</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1254</th>
      <td>12833.549805</td>
      <td>12767.639648</td>
      <td>12791.540039</td>
      <td>12804.730469</td>
      <td>3305950000</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1255</th>
      <td>12930.889648</td>
      <td>12827.450195</td>
      <td>12914.639648</td>
      <td>12899.419922</td>
      <td>5076340000</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1256</th>
      <td>12973.330078</td>
      <td>12821.959961</td>
      <td>12965.389648</td>
      <td>12850.219727</td>
      <td>4680780000</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1257</th>
      <td>12924.929688</td>
      <td>12857.759766</td>
      <td>12906.509766</td>
      <td>12870.000000</td>
      <td>5292210000</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1258</th>
      <td>12902.070313</td>
      <td>12821.230469</td>
      <td>12877.089844</td>
      <td>12888.280273</td>
      <td>4771390000</td>
      <td>12</td>
    </tr>
  </tbody>
</table>
<p>1259 rows × 6 columns</p>
</div>




```python
# We add a prediction column and set dummy values to prepare the data for scaling
data_filtered_ext = data_filtered.copy()
data_filtered_ext['Prediction'] = data_filtered_ext['Close']

```


```python
# Print the tail of the dataframe
data_filtered_ext.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>High</th>
      <th>Low</th>
      <th>Open</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Month</th>
      <th>Prediction</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4903.089844</td>
      <td>4846.979980</td>
      <td>4897.649902</td>
      <td>4903.089844</td>
      <td>2218420000</td>
      <td>01</td>
      <td>4903.089844</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4926.729980</td>
      <td>4872.740234</td>
      <td>4917.839844</td>
      <td>4891.430176</td>
      <td>1927380000</td>
      <td>01</td>
      <td>4891.430176</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4866.040039</td>
      <td>4804.689941</td>
      <td>4813.759766</td>
      <td>4835.759766</td>
      <td>2168620000</td>
      <td>01</td>
      <td>4835.759766</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4788.020020</td>
      <td>4688.169922</td>
      <td>4736.399902</td>
      <td>4689.430176</td>
      <td>2552590000</td>
      <td>01</td>
      <td>4689.430176</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4742.569824</td>
      <td>4637.850098</td>
      <td>4722.020020</td>
      <td>4643.629883</td>
      <td>2288750000</td>
      <td>01</td>
      <td>4643.629883</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Get the number of rows in the data
nrows = data_filtered.shape[0]
nrows
```




    1259




```python
# Convert the data to numpy values
np_data_unscaled = np.array(data_filtered)
np_data_unscaled.shape
```




    (1259, 6)




```python
np_data = np.reshape(np_data_unscaled, (nrows, -1))
print(np_data.shape)
```

    (1259, 6)
    


```python
np_data
```




    array([[4903.089844, 4846.97998, 4897.649902, 4903.089844, 2218420000,
            '01'],
           [4926.72998, 4872.740234, 4917.839844, 4891.430176, 1927380000,
            '01'],
           [4866.040039, 4804.689941, 4813.759766, 4835.759766, 2168620000,
            '01'],
           ...,
           [12973.330078, 12821.959961, 12965.389648, 12850.219727,
            4680780000, '12'],
           [12924.929688, 12857.759766, 12906.509766, 12870.0, 5292210000,
            '12'],
           [12902.070313, 12821.230469, 12877.089844, 12888.280273,
            4771390000, '12']], dtype=object)




```python
# Transform the data by scaling each feature to a range between 0 and 1
scaler = MinMaxScaler()
np_data_scaled = scaler.fit_transform(np_data_unscaled)
```


```python
# Creating a separate scaler that works on a single column for scaling predictions
scaler_pred = MinMaxScaler()
df_Close = pd.DataFrame(data_filtered_ext['Close'])
df_Close
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4903.089844</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4891.430176</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4835.759766</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4689.430176</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4643.629883</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1254</th>
      <td>12804.730469</td>
    </tr>
    <tr>
      <th>1255</th>
      <td>12899.419922</td>
    </tr>
    <tr>
      <th>1256</th>
      <td>12850.219727</td>
    </tr>
    <tr>
      <th>1257</th>
      <td>12870.000000</td>
    </tr>
    <tr>
      <th>1258</th>
      <td>12888.280273</td>
    </tr>
  </tbody>
</table>
<p>1259 rows × 1 columns</p>
</div>




```python
np_Close_scaled = scaler_pred.fit_transform(df_Close)
```


```python
sequence_length = 50
```


```python
index_Close = data.columns.get_loc("Close")
```


```python
train_data_len = math.ceil(np_data_scaled.shape[0] * 0.8)
train_data_len
```




    1008




```python
train_data = np_data_scaled[0:train_data_len, :]
test_data = np_data_scaled[train_data_len - sequence_length:, :]
```


```python
def partition_dataset(sequence_length, data):
    x, y = [], []
    data_len = data.shape[0]
    for i in range(sequence_length, data_len):
        x.append(data[i-sequence_length:i,:]) #contains sequence_length values 0-sequence_length * columsn
        y.append(data[i, index_Close]) #contains the prediction values for validation,  for single-step prediction
    x = np.array(x)
    y = np.array(y)
    return x, y
```


```python
 #Generate training data and test data
x_train, y_train = partition_dataset(sequence_length, train_data)
x_test, y_test = partition_dataset(sequence_length, test_data)

```


```python
print(x_train.shape, y_train.shape)
print(x_test.shape, y_test.shape)

```

    (958, 50, 6) (958,)
    (251, 50, 6) (251,)
    


```python
x_train
```




    array([[[0.07026059, 0.07368411, 0.07761204, 0.07370334, 0.27425829,
             0.        ],
            [0.07298407, 0.07666287, 0.07992036, 0.07235268, 0.23567939,
             0.        ],
            [0.06599223, 0.06879396, 0.06802084, 0.06590381, 0.26765703,
             0.        ],
            ...,
            [0.05248434, 0.05679352, 0.05643004, 0.05579217, 0.21903176,
             0.18181818],
            [0.05403731, 0.06033187, 0.05883215, 0.05600179, 0.19428501,
             0.18181818],
            [0.05092675, 0.05808396, 0.05857491, 0.0534985 , 0.20453419,
             0.18181818]],
    
           [[0.07298407, 0.07666287, 0.07992036, 0.07235268, 0.23567939,
             0.        ],
            [0.06599223, 0.06879396, 0.06802084, 0.06590381, 0.26765703,
             0.        ],
            [0.05700386, 0.05532032, 0.05917626, 0.04895296, 0.3185543 ,
             0.        ],
            ...,
            [0.05403731, 0.06033187, 0.05883215, 0.05600179, 0.19428501,
             0.18181818],
            [0.05092675, 0.05808396, 0.05857491, 0.0534985 , 0.20453419,
             0.18181818],
            [0.05547851, 0.05859048, 0.05705886, 0.05758769, 0.21628389,
             0.18181818]],
    
           [[0.06599223, 0.06879396, 0.06802084, 0.06590381, 0.26765703,
             0.        ],
            [0.05700386, 0.05532032, 0.05917626, 0.04895296, 0.3185543 ,
             0.        ],
            [0.05176773, 0.04950166, 0.0575322 , 0.04364744, 0.2835809 ,
             0.        ],
            ...,
            [0.05092675, 0.05808396, 0.05857491, 0.0534985 , 0.20453419,
             0.18181818],
            [0.05547851, 0.05859048, 0.05705886, 0.05758769, 0.21628389,
             0.18181818],
            [0.05701191, 0.06107891, 0.06103072, 0.05886425, 0.23300309,
             0.18181818]],
    
           ...,
    
           [[0.44517174, 0.44352571, 0.44943741, 0.44282244, 0.24701949,
             0.81818182],
            [0.44595287, 0.45183858, 0.44801626, 0.45133093, 0.21254583,
             0.81818182],
            [0.44946435, 0.45007172, 0.45381283, 0.44453222, 0.2250511 ,
             0.81818182],
            ...,
            [0.54483639, 0.55026598, 0.54322948, 0.55088395, 0.19691226,
             1.        ],
            [0.54823958, 0.55244687, 0.55229128, 0.5490572 , 0.22306277,
             1.        ],
            [0.54298162, 0.54341243, 0.54714418, 0.54203382, 0.25092855,
             1.        ]],
    
           [[0.44595287, 0.45183858, 0.44801626, 0.45133093, 0.21254583,
             0.81818182],
            [0.44946435, 0.45007172, 0.45381283, 0.44453222, 0.2250511 ,
             0.81818182],
            [0.44119945, 0.44733931, 0.44262219, 0.44632661, 0.21946124,
             0.81818182],
            ...,
            [0.54823958, 0.55244687, 0.55229128, 0.5490572 , 0.22306277,
             1.        ],
            [0.54298162, 0.54341243, 0.54714418, 0.54203382, 0.25092855,
             1.        ],
            [0.53941024, 0.54382629, 0.53734493, 0.54511626, 0.26953667,
             1.        ]],
    
           [[0.44946435, 0.45007172, 0.45381283, 0.44453222, 0.2250511 ,
             0.81818182],
            [0.44119945, 0.44733931, 0.44262219, 0.44632661, 0.21946124,
             0.81818182],
            [0.44868322, 0.45419755, 0.45288903, 0.4539732 , 0.22972898,
             0.81818182],
            ...,
            [0.54298162, 0.54341243, 0.54714418, 0.54203382, 0.25092855,
             1.        ],
            [0.53941024, 0.54382629, 0.53734493, 0.54511626, 0.26953667,
             1.        ],
            [0.55301253, 0.55517228, 0.55114686, 0.55896969, 0.35776151,
             0.        ]]])




```python
print(x_train[1][sequence_length-1][index_Close])
print(y_train[0])
```

    0.05758769296179822
    0.05758769296179822
    

# Step #4 Model Training


```python
# Configure the neural network model
model = Sequential()
n_neurons = x_train.shape[1] * x_train.shape[2]
```


```python
print(n_neurons, x_train.shape[1], x_train.shape[2])
```

    300 50 6
    


```python
model.add(LSTM(n_neurons, return_sequences=True, input_shape=(x_train.shape[1], x_train.shape[2]))) 
model.add(LSTM(n_neurons, return_sequences=False))
model.add(Dense(5))
model.add(Dense(1))

```


```python
# Compile the model
model.compile(optimizer='adam', loss='mse')
```


```python
# Training the model
epochs = 50
batch_size = 16
early_stop = EarlyStopping(monitor='loss', patience=5, verbose=1)
history = model.fit(x_train, y_train, 
                    batch_size=batch_size, 
                    epochs=epochs,
                    validation_data=(x_test, y_test)
                   )
                    
                    #callbacks=[early_stop])
```

    Epoch 1/50
    60/60 [==============================] - 26s 372ms/step - loss: 0.0051 - val_loss: 0.0044
    Epoch 2/50
    60/60 [==============================] - 20s 337ms/step - loss: 2.6378e-04 - val_loss: 0.0050
    Epoch 3/50
    60/60 [==============================] - 20s 336ms/step - loss: 2.2834e-04 - val_loss: 0.0037
    Epoch 4/50
    60/60 [==============================] - 18s 296ms/step - loss: 2.1125e-04 - val_loss: 0.0032
    Epoch 5/50
    60/60 [==============================] - 19s 324ms/step - loss: 1.9858e-04 - val_loss: 0.0047
    Epoch 6/50
    60/60 [==============================] - 19s 315ms/step - loss: 2.1609e-04 - val_loss: 0.0031
    Epoch 7/50
    60/60 [==============================] - 21s 350ms/step - loss: 2.2405e-04 - val_loss: 0.0020
    Epoch 8/50
    60/60 [==============================] - 25s 413ms/step - loss: 2.2806e-04 - val_loss: 0.0044
    Epoch 9/50
    60/60 [==============================] - 23s 381ms/step - loss: 2.3792e-04 - val_loss: 0.0022
    Epoch 10/50
    60/60 [==============================] - 21s 358ms/step - loss: 1.7200e-04 - val_loss: 0.0025
    Epoch 11/50
    60/60 [==============================] - 22s 367ms/step - loss: 1.8407e-04 - val_loss: 0.0036
    Epoch 12/50
    60/60 [==============================] - 21s 346ms/step - loss: 1.8622e-04 - val_loss: 0.0024
    Epoch 13/50
    60/60 [==============================] - 24s 407ms/step - loss: 1.6335e-04 - val_loss: 0.0013
    Epoch 14/50
    60/60 [==============================] - 24s 399ms/step - loss: 1.6386e-04 - val_loss: 0.0014
    Epoch 15/50
    60/60 [==============================] - 23s 380ms/step - loss: 2.0297e-04 - val_loss: 0.0017
    Epoch 16/50
    60/60 [==============================] - 21s 352ms/step - loss: 1.4853e-04 - val_loss: 0.0015
    Epoch 17/50
    60/60 [==============================] - 17s 287ms/step - loss: 1.3762e-04 - val_loss: 0.0016
    Epoch 18/50
    60/60 [==============================] - 18s 296ms/step - loss: 1.6959e-04 - val_loss: 0.0019
    Epoch 19/50
    60/60 [==============================] - 18s 292ms/step - loss: 1.4093e-04 - val_loss: 0.0013
    Epoch 20/50
    60/60 [==============================] - 17s 283ms/step - loss: 1.3363e-04 - val_loss: 0.0025
    Epoch 21/50
    60/60 [==============================] - 17s 288ms/step - loss: 1.3950e-04 - val_loss: 0.0016
    Epoch 22/50
    60/60 [==============================] - 17s 283ms/step - loss: 1.5000e-04 - val_loss: 0.0012
    Epoch 23/50
    60/60 [==============================] - 17s 283ms/step - loss: 1.3428e-04 - val_loss: 0.0015
    Epoch 24/50
    60/60 [==============================] - 17s 282ms/step - loss: 1.4652e-04 - val_loss: 0.0016
    Epoch 25/50
    60/60 [==============================] - 17s 285ms/step - loss: 1.4167e-04 - val_loss: 7.6817e-04
    Epoch 26/50
    60/60 [==============================] - 17s 283ms/step - loss: 1.4335e-04 - val_loss: 0.0023
    Epoch 27/50
    60/60 [==============================] - 17s 291ms/step - loss: 1.3801e-04 - val_loss: 0.0028
    Epoch 28/50
    60/60 [==============================] - 17s 286ms/step - loss: 1.3951e-04 - val_loss: 0.0011
    Epoch 29/50
    60/60 [==============================] - 17s 290ms/step - loss: 1.2436e-04 - val_loss: 0.0013
    Epoch 30/50
    60/60 [==============================] - 18s 297ms/step - loss: 1.4711e-04 - val_loss: 0.0017
    Epoch 31/50
    60/60 [==============================] - 18s 305ms/step - loss: 1.2617e-04 - val_loss: 7.3198e-04
    Epoch 32/50
    60/60 [==============================] - 19s 314ms/step - loss: 1.1497e-04 - val_loss: 0.0012
    Epoch 33/50
    60/60 [==============================] - 18s 301ms/step - loss: 1.0167e-04 - val_loss: 6.8993e-04
    Epoch 34/50
    60/60 [==============================] - 18s 295ms/step - loss: 1.1341e-04 - val_loss: 9.5558e-04
    Epoch 35/50
    60/60 [==============================] - 18s 297ms/step - loss: 1.1277e-04 - val_loss: 7.4506e-04
    Epoch 36/50
    60/60 [==============================] - 19s 320ms/step - loss: 1.2576e-04 - val_loss: 7.6706e-04
    Epoch 37/50
    60/60 [==============================] - 21s 348ms/step - loss: 1.0217e-04 - val_loss: 9.0961e-04
    Epoch 38/50
    60/60 [==============================] - 26s 439ms/step - loss: 1.3758e-04 - val_loss: 0.0016
    Epoch 39/50
    60/60 [==============================] - 21s 355ms/step - loss: 9.6281e-05 - val_loss: 7.6010e-04
    Epoch 40/50
    60/60 [==============================] - 19s 319ms/step - loss: 9.4413e-05 - val_loss: 5.9890e-04
    Epoch 41/50
    60/60 [==============================] - 18s 308ms/step - loss: 8.0907e-05 - val_loss: 8.2705e-04
    Epoch 42/50
    60/60 [==============================] - 18s 300ms/step - loss: 1.1128e-04 - val_loss: 9.0452e-04
    Epoch 43/50
    60/60 [==============================] - 18s 303ms/step - loss: 9.7638e-05 - val_loss: 8.6913e-04
    Epoch 44/50
    60/60 [==============================] - 19s 313ms/step - loss: 8.8546e-05 - val_loss: 6.6838e-04
    Epoch 45/50
    60/60 [==============================] - 19s 313ms/step - loss: 9.6851e-05 - val_loss: 5.4279e-04
    Epoch 46/50
    60/60 [==============================] - 19s 320ms/step - loss: 1.0251e-04 - val_loss: 0.0011
    Epoch 47/50
    60/60 [==============================] - 18s 307ms/step - loss: 1.1360e-04 - val_loss: 7.3285e-04
    Epoch 48/50
    60/60 [==============================] - 18s 299ms/step - loss: 1.0899e-04 - val_loss: 5.2989e-04
    Epoch 49/50
    60/60 [==============================] - 19s 312ms/step - loss: 9.1386e-05 - val_loss: 7.5530e-04
    Epoch 50/50
    60/60 [==============================] - 19s 322ms/step - loss: 7.7697e-05 - val_loss: 5.9673e-04
    


```python
# Plot training & validation loss values
fig, ax = plt.subplots(figsize=(20, 10), sharex=True)
plt.plot(history.history["loss"])
plt.title("Model loss")
plt.ylabel("Loss")
plt.xlabel("Epoch")
ax.xaxis.set_major_locator(plt.MaxNLocator(epochs))
plt.legend(["Train", "Test"], loc="upper left")
plt.grid()
plt.show()
```


    
![png](output_37_0.png)
    


# Step #5 Evaluate Model Performance


```python
# Get the predicted values
y_pred_scaled = model.predict(x_test)
```


```python
# Unscale the predicted values
y_pred = scaler_pred.inverse_transform(y_pred_scaled)
y_test_unscaled = scaler_pred.inverse_transform(y_test.reshape(-1, 1))
```


```python
# Mean Absolute Error (MAE)
MAE = mean_absolute_error(y_test_unscaled, y_pred)
print(f'Median Absolute Error (MAE): {np.round(MAE, 2)}')
```

    Median Absolute Error (MAE): 166.3
    


```python
# Mean Absolute Percentage Error (MAPE)
MAPE = np.mean((np.abs(np.subtract(y_test_unscaled, y_pred)/ y_test_unscaled))) * 100
print(f'Mean Absolute Percentage Error (MAPE): {np.round(MAPE, 2)} %')
```

    Mean Absolute Percentage Error (MAPE): 1.7 %
    


```python
# Median Absolute Percentage Error (MDAPE)
MDAPE = np.median((np.abs(np.subtract(y_test_unscaled, y_pred)/ y_test_unscaled)) ) * 100
print(f'Median Absolute Percentage Error (MDAPE): {np.round(MDAPE, 2)} %')
```

    Median Absolute Percentage Error (MDAPE): 1.43 %
    
